# Scripts

- `data.js` contains mock data + `localStorage` persistence.
- `app.js` contains the functional behaviors (filters, modals, toasts, offline/sync simulation).

## Recommended entrypoint

- `waitlist.bundle.js` is the self-contained (no-server) bundle used by `Views/Waitlist/WaitlistPage.html`.

No build step required.
