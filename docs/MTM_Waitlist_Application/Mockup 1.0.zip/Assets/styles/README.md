# Styles

`app.css` is a Fluent-inspired theme (acrylic surfaces, Segoe UI, soft radii) designed to avoid "developer tool" intimidation.
